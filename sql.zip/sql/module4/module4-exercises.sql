-- 1. Count all authors


-- 2. Calculate the average price of all titles


-- 3. Count authors per city


-- 4. Count titles per type


-- 5. Count authors per state having more than 1 author


-- 6. Find the maximum price of titles per type, having maximum price greater than 15


-- 7. Find the minimum price of titles per type, having minimum price less than 20


-- 8. Count publishers per country having more than 1 publisher


-- 9. Find the average price of titles per type where the advance is greater than 5000 and sort them in descending order


-- 10. Find the minimum and maximum price of titles per type, where the type has more than 2 titles and the average price is greater than 15


-- 11. Count publishers per country having more than 2 publishers and where the country name starts with 'U'


