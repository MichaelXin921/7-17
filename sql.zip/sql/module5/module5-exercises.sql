
-- 1. Inner join authors with titleauthor based on au_id. 

-- 2. Inner join titles with publishers and show only titles, price, and publisher name. 

-- 3. Inner join titles with publishers, and show the average price of books for each publisher.

-- 4. Inner join authors with titles and show only authors' names and titles' names. Hint: use your query solution from question 1 to get started.

-- 5. Retrieve the title_id of any titles with multiple authors.

-- 6. Duplicate and edit the previous query to find the names of any titles with multiple authors. 
